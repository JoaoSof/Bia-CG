﻿/**
 * author: Jederson Sousa Luz 
 * email: jedersonalpha@gmail.com
 * data: 06/05/2017 
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveObject : MonoBehaviour {

    /*Como esse objeto está público você pode dizer quem ele é pela unity
    clicando no objeto que esta com o script dentro dele, que no caso é a canvas, 
    e arrastando-o para a zona da variável que aparece no componente do script*/
	public GameObject cubo;

    //método para mover o cubo para cima
	public void buttonUp () {
		cubo.transform.position += Vector3.up * 1;
	}

    //método para mover o cubo para baixo
	public void buttonDown () {
		cubo.transform.position += Vector3.down * 1;
	}

    //método para mover o cubo para direita
	public void buttonRight () {
		cubo.transform.position += Vector3.right * 1;
	}

    //método para mover o cubo para esquerda
	public void buttonLeft () {
		cubo.transform.position += Vector3.left * 1;
	}

	//método para girar o cubo para cima
	public void buttonRotateUp () {
		cubo.transform.Rotate(Vector3.right * 1);
	}

	//método para girar o cubo para baixo
	public void buttonRotateDown () {
		cubo.transform.Rotate(Vector3.left * 1);
	}

	//método para girar o cubo para direita
	public void buttonRotateRight () {
		cubo.transform.Rotate(Vector3.down * 1);
	}

	//método para girar o cubo para esquerda
	public void buttonRotateLeft () {
        cubo.transform.Rotate(Vector3.up * 1);
	}
}
