﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColisorChao : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other){

		//zerando as forcas
		other.GetComponent<Rigidbody> ().velocity = Vector3.zero;
		other.GetComponent<Rigidbody> ().angularVelocity = Vector3.zero;
		other.GetComponent<Rigidbody> ().Sleep();

		Debug.Log ("Pousado");
		//Se cair voltar pro cenario
		if(other.GetComponent<Rigidbody>().position.y < 0){
			float x = other.transform.position.x;
			float z = other.transform.position.z;
			other.transform.position = new Vector3 (x,1.5f,z);
		}
		//other.GetComponent<Rigidbody> ().velocity = new Vector3 (0, 0, 0);
		//other.GetComponent<Rigidbody> ().AddForce(Vector3.up * 100);

//		GetComponent<Rigidbody> ().velocity = new Vector3 (0, 0, 0);
		//transform.Translate (3, 0, 0);
	}

}
